// lib/utils.ts
// ─────────────────────────────────────────────────────────────────────────────
// Canonical — dipindahkan dari shared/lib/helpers.ts ke sini.
// shared/lib/helpers.ts dihapus.
// ─────────────────────────────────────────────────────────────────────────────

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

// ── Tailwind merge ────────────────────────────────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ── Color helpers ─────────────────────────────────────────────────────────────
export { getPaletteColor as getColor } from "@/constants/shared";

export const getInitials = (name: string): string =>
  name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

// ── Re-export dari constants/shared ──────────────────────────────────────────
export { STATUS_MAP as statusMap, RANK_COLORS as rankColors } from "@/constants/shared";

// ── Time helpers ──────────────────────────────────────────────────────────────
export const timeAgo = (dateStr: string): string => {
  const days = Math.floor(
    (Date.now() - new Date(dateStr).getTime()) / 86400000,
  );
  if (days === 0) return "Hari ini";
  if (days === 1) return "1 hari lalu";
  if (days < 7) return `${days} hari lalu`;
  if (days < 30) return `${Math.floor(days / 7)} minggu lalu`;
  return `${Math.floor(days / 30)} bulan lalu`;
};

// ── Date format helpers ───────────────────────────────────────────────────────
export const formatDeadline = (d: string | null): string =>
  d
    ? new Date(d).toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric",
      })
    : "—";

// ── String helpers ────────────────────────────────────────────────────────────
export function parseRequirements(
  raw: string | string[] | null | undefined,
): string[] {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw.map((s) => s.trim()).filter(Boolean);
  return raw
    .split(/\\n|\n/)
    .map((s) => s.trim().replace(/^[-•*–]\s*/, ""))
    .filter(Boolean);
}
