// constants/candidate/applications.ts
// ─────────────────────────────────────────────────────────────────────────────
// Re-export types dari source of truth — jangan definisikan ulang di sini.
// ─────────────────────────────────────────────────────────────────────────────

export type {
  Application,
  ApplicationStatus,
  Interview,
  InterviewType,
  InterviewStatus,
  AIInsight,
} from "@/types/candidate-dashboard";

// STATUS_MAP & IV_STATUS_MAP dikonsolidasi ke shared.ts
export { STATUS_MAP, IV_STATUS_MAP } from "../shared";

// CARD_COLORS → alias PALETTE_COLORS di constants/shared.ts
export { PALETTE_COLORS as CARD_COLORS } from "../shared";
