// constants/hr-dashboard.ts

import { FilterOption } from "@/types/hr-dashboard";
import { CheckCircle2, AlertCircle, XCircle } from "lucide-react";

export const HR_DASHBOARD_REVALIDATE = 60; // detik

/** Base URL untuk semua API call — dipakai juga oleh shared/lib/api.ts. */
export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "";

/** Jumlah skill maksimal yang ditampilkan per kandidat. */
export const MAX_SKILLS_DISPLAYED = 5;

export const REC_ICON_MAP = { CheckCircle2, AlertCircle, XCircle } as const;

// RANK_COLORS → canonical di constants/shared.ts
export { RANK_COLORS } from "./shared";

export const TABLE_HEADERS = [
  "#", "Kandidat", "AI Score", "Match", "Skills", "Rekomendasi", "Status", "Aksi",
] as const;

export const STATUS_FILTER_OPTIONS: FilterOption[] = [
  { value: "all",         label: "Semua Status" },
  { value: "applied",     label: "Applied"      },
  { value: "review",      label: "In Review"    },
  { value: "shortlisted", label: "Shortlisted"  },
  { value: "rejected",    label: "Ditolak"      },
];
