"use client";

import { useState, useCallback } from "react";
import type { Interview } from "@/types/calendar";
import type { EvaluationResult } from "@/components/hr/interviews/EvaluationModal";
import { sendRejectionAction } from "@/actions/rejectionActions";
import { apiFetch } from "@/lib/api";

export type EvaluationFlowStage =
  | "idle"
  | "evaluating"
  | "submitting"
  | "offering"
  | "sending_rejection"
  | "done_offer"
  | "done_rejection"
  | "done_consider"
  | "error";

export interface EvaluationFlowState {
  stage: EvaluationFlowStage;
  interview: Interview | null;
  candidateEmail: string;
  companyName: string;
  evaluation: EvaluationResult | null;
  errorMessage: string;
}

/**
 * Orchestrates the post-interview flow:
 *   1. HR opens EvaluationModal            → stage: "evaluating"
 *   1b. Evaluation is persisted to backend → stage: "submitting"
 *   2a. Hire → opens OfferLetterModal      → stage: "offering"
 *   2b. Reject → sends rejection email     → stage: "sending_rejection" → "done_rejection"
 *   2c. Consider → saved, no email sent    → stage: "done_consider"
 *   3. Offer sent                           → stage: "done_offer"
 *
 * Usage:
 *   const flow = useEvaluationFlow(token, fetchData);
 *   flow.start(interview, candidateEmail, companyName);
 *
 * `onSuccess` (opsional) dipanggil setiap kali evaluasi berhasil tersimpan
 * ke backend (hire/reject/consider) — dipakai parent untuk refetch list
 * interview supaya UI (status/tombol Evaluate) langsung ter-update tanpa
 * perlu reload manual.
 */
export function useEvaluationFlow(token: string, onSuccess?: () => void) {
  const [state, setState] = useState<EvaluationFlowState>({
    stage: "idle",
    interview: null,
    candidateEmail: "",
    companyName: "",
    evaluation: null,
    errorMessage: "",
  });

  /** Step 1 — HR clicks "Evaluate" on an interview card */
  const start = useCallback(
    (interview: Interview, candidateEmail: string, companyName: string) => {
      setState({
        stage: "evaluating",
        interview,
        candidateEmail,
        companyName,
        evaluation: null,
        errorMessage: "",
      });
    },
    [],
  );

  /**
   * Simpan evaluasi ke POST /api/evaluations. Dipanggil di ketiga cabang
   * (hire/reject/consider) karena score & notes harus tetap tersimpan
   * apapun rekomendasi HR-nya — sebelumnya evaluasi cuma hidup di state
   * React lalu hilang begitu modal ditutup, ga pernah kekirim ke backend.
   */
  const saveEvaluation = useCallback(
    async (interview: Interview, evaluation: EvaluationResult) => {
      await apiFetch("/api/evaluations", token, {
        method: "POST",
        body: JSON.stringify({
          application_id: interview.application_id,
          interview_id: interview.id,
          score: evaluation.score,
          recommendation: evaluation.recommendation,
          notes: evaluation.notes,
        }),
      });
    },
    [token],
  );

  /** Step 2a — HR chose "Hire" in EvaluationModal */
  const handleHire = useCallback(
    async (evaluation: EvaluationResult) => {
      const { interview } = state;
      if (!interview) return;

      setState((prev) => ({ ...prev, stage: "submitting", evaluation }));

      try {
        await saveEvaluation(interview, evaluation);
        onSuccess?.();
      } catch (err) {
        setState((prev) => ({
          ...prev,
          stage: "error",
          errorMessage:
            err instanceof Error ? err.message : "Gagal menyimpan evaluasi.",
        }));
        return;
      }

      setState((prev) => ({ ...prev, stage: "offering" }));
    },
    [state, saveEvaluation, onSuccess],
  );

  /** Step 2b — HR chose "Reject" → save, then fire-and-forget email */
  const handleReject = useCallback(
    async (evaluation: EvaluationResult) => {
      const { interview, candidateEmail, companyName } = state;
      if (!interview) return;

      setState((prev) => ({ ...prev, stage: "submitting", evaluation }));

      try {
        await saveEvaluation(interview, evaluation);
        onSuccess?.();
      } catch (err) {
        setState((prev) => ({
          ...prev,
          stage: "error",
          errorMessage:
            err instanceof Error ? err.message : "Gagal menyimpan evaluasi.",
        }));
        return;
      }

      setState((prev) => ({ ...prev, stage: "sending_rejection" }));

      const result = await sendRejectionAction({
        applicationId: interview.application_id,
        candidateName: interview.candidate_name ?? "Candidate",
        candidateEmail,
        jobTitle: interview.job_title ?? "",
        companyName,
        feedback: evaluation.notes,
      });

      if (!result.success) {
        setState((prev) => ({
          ...prev,
          stage: "error",
          errorMessage: result.error,
        }));
        return;
      }

      setState((prev) => ({ ...prev, stage: "done_rejection" }));
    },
    [state, saveEvaluation, onSuccess],
  );

  /** Step 2c — HR chose "Consider" → save only, no email, no notification */
  const handleConsider = useCallback(
    async (evaluation: EvaluationResult) => {
      const { interview } = state;
      if (!interview) return;

      setState((prev) => ({ ...prev, stage: "submitting", evaluation }));

      try {
        await saveEvaluation(interview, evaluation);
        onSuccess?.();
      } catch (err) {
        setState((prev) => ({
          ...prev,
          stage: "error",
          errorMessage:
            err instanceof Error ? err.message : "Gagal menyimpan evaluasi.",
        }));
        return;
      }

      setState((prev) => ({ ...prev, stage: "done_consider" }));
    },
    [state, saveEvaluation, onSuccess],
  );

  /** Step 3 — Offer letter sent successfully */
  const handleOfferSent = useCallback(() => {
    setState((prev) => ({ ...prev, stage: "done_offer" }));
  }, []);

  /** Reset to idle (close all modals) */
  const reset = useCallback(() => {
    setState({
      stage: "idle",
      interview: null,
      candidateEmail: "",
      companyName: "",
      evaluation: null,
      errorMessage: "",
    });
  }, []);

  return {
    ...state,
    start,
    handleHire,
    handleReject,
    handleConsider,
    handleOfferSent,
    reset,
  };
}