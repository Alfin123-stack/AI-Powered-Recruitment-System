// types/calendar.ts
// ─────────────────────────────────────────────────────────────────────────────
// Single source of truth untuk type Interview.
// Sebelumnya didefinisikan ulang di:
//   - candidate-dashboard.ts (subset — tanpa interviewer, duration, round)
//   - hr-dashboard.ts (hampir sama dengan hr/interviews.ts, tanpa recording_duration)
//   - hr/interviews.ts (paling lengkap sisi HR, + recording_duration)
// ─────────────────────────────────────────────────────────────────────────────

export type InterviewType = "online" | "onsite";

// hr/interviews.ts menambah "scheduled_late" di InterviewStatusKey (konstanta UI),
// tapi status data dari DB hanya 4 nilai ini.
export type InterviewStatus = "scheduled" | "done" | "cancelled" | "overdue";

export type ViewMode = "month" | "week" | "day";

export type Interview = {
  id: string;
  application_id: string;
  scheduled_at: string;
  type: InterviewType;
  location: string | null;
  notes?: string | null;
  status: InterviewStatus;
  // — Data job/pelamar (optional: tidak selalu di-join)
  job_title?: string;
  company_name?: string;
  candidate_name?: string;
  candidate_id?: string;
  // — Data interviewer
  interviewer_name?: string;
  interviewer_avatar?: string;
  // — Metadata tambahan
  duration_minutes?: number;
  round?: string;
  recording_duration?: string;
  created_at?: string;
};
