// types/candidates.ts
// ─────────────────────────────────────────────────────────────────────────────
// Types untuk tabel kandidat sisi HR (filtering, sorting, pagination).
// Application & ApplicationStatus → canonical di candidate-dashboard.ts
// ─────────────────────────────────────────────────────────────────────────────

import type { Candidate } from "@/app/(role)/dashboard/hr/_components/shared";

export type { ApplicationStatus, RawApplication } from "./candidate-dashboard";

export type SortKey = "score" | "match" | "name" | "date" | "applied_role";
export type SortDir = "asc" | "desc";
export type StatusFilter =
  | "all"
  | "applied"
  | "review"
  | "shortlisted"
  | "rejected";
export type CandidateStatus =
  | "applied"
  | "review"
  | "shortlisted"
  | "rejected"
  | "hired";
export type DateFilter =
  | "Last 7 days"
  | "Last 30 days"
  | "Last 90 days"
  | "All time";

export interface JobMeta {
  key: string;
  label: string;
  color: string;
  count: number;
  todayCount: number;
}

// CandidateRaw meng-extend Candidate dari _components/shared (raw DB shape).
// Berbeda dari CandidateUI di hr-dashboard.ts yang merupakan representasi UI (camelCase).
export interface CandidateRaw extends Candidate {
  created_at: string;
  email: string;
  phone: string;
  location: string;
}

/** @deprecated Gunakan `CandidateRaw` */
export type CandidateExtended = CandidateRaw;
